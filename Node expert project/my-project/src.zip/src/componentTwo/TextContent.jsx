import React from 'react';
import './TextContent.css'

const TextContent = () => {
  return (
    <div className="TextContentHeader">
      <h3>We provide various kind of <br />learning modules for you</h3>
    </div>
  )
}

export default TextContent
