import React from 'react';
import './SmallText.css'

const SmallText = () => {
  return (
    <div className="SmallTextContent">
      <p>It Is A Long Established Fact That A Reader Will Be Distracted By The Readable <br />Content Of A Page When Looking At Its Layout. The Point Of Using Lorem</p>
    </div>
  )
}

export default SmallText
