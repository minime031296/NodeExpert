import React from 'react';
import './four.css'

const Four = () => {
  return (
    <div className='four'>
      <h3><b>We Completed 1200+ Certification Program <br />Successfully & Counting</b></h3>
    </div>
  )
}

export default Four
