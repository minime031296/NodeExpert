import React from 'react'
import './one.css'

const One = () => {
  return (
    <div className='one'>
      <h2>Why Us</h2>
    </div>
  )
}

export default One
